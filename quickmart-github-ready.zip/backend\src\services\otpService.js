const { logOtp } = require("../db");

async function sendOtp(payload, env) {
  const provider = String(env.OTP_PROVIDER || "demo").toLowerCase();
  const mobile = String(payload.mobile || "").replace(/\D/g, "").slice(-10);
  const otp = String(payload.otp || "").replace(/\D/g, "").slice(0, 6);

  if (mobile.length !== 10 || otp.length !== 6) {
    return { ok: false, message: "Invalid mobile or OTP." };
  }

  if (provider === "demo") {
    logOtp({
      mobile,
      provider,
      status: "demo-success",
      request: payload,
      response: { message: "Demo OTP mode active." }
    });
    return { ok: true, provider: "demo", message: "Demo OTP handled." };
  }

  if (provider === "msg91") {
    const authKey = String(env.MSG91_AUTH_KEY || "").trim();
    const templateId = String(env.MSG91_TEMPLATE_ID || "").trim();
    if (!authKey || !templateId) {
      return { ok: false, message: "MSG91 credentials missing in backend .env." };
    }

    const url = `https://api.msg91.com/api/v5/otp?template_id=${encodeURIComponent(templateId)}&mobile=91${mobile}&otp=${otp}`;
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          authkey: authKey,
          "Content-Type": "application/json"
        }
      });
      const text = await response.text();
      const ok = response.ok;
      logOtp({
        mobile,
        provider,
        status: ok ? "success" : "failed",
        error: ok ? "" : `HTTP ${response.status}`,
        request: { url, mobile },
        response: { status: response.status, body: text }
      });
      return ok
        ? { ok: true, provider: "msg91", message: "OTP sent via MSG91." }
        : { ok: false, message: `MSG91 failed (${response.status}).` };
    } catch (error) {
      logOtp({
        mobile,
        provider,
        status: "failed",
        error: error.message,
        request: { mobile },
        response: {}
      });
      return { ok: false, message: `MSG91 error: ${error.message}` };
    }
  }

  if (provider === "twilio_verify") {
    const sid = String(env.TWILIO_ACCOUNT_SID || "").trim();
    const token = String(env.TWILIO_AUTH_TOKEN || "").trim();
    const serviceSid = String(env.TWILIO_VERIFY_SERVICE_SID || "").trim();
    if (!sid || !token || !serviceSid) {
      return { ok: false, message: "Twilio Verify credentials missing in backend .env." };
    }

    const body = new URLSearchParams();
    body.set("To", `+91${mobile}`);
    body.set("Channel", "sms");
    body.set("CustomCode", otp);

    const auth = Buffer.from(`${sid}:${token}`).toString("base64");
    const url = `https://verify.twilio.com/v2/Services/${serviceSid}/Verifications`;
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Basic ${auth}`,
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: body.toString()
      });
      const text = await response.text();
      const ok = response.ok;
      logOtp({
        mobile,
        provider,
        status: ok ? "success" : "failed",
        error: ok ? "" : `HTTP ${response.status}`,
        request: { mobile },
        response: { status: response.status, body: text }
      });
      return ok
        ? { ok: true, provider: "twilio_verify", message: "OTP sent via Twilio Verify." }
        : { ok: false, message: `Twilio Verify failed (${response.status}).` };
    } catch (error) {
      logOtp({
        mobile,
        provider,
        status: "failed",
        error: error.message,
        request: { mobile },
        response: {}
      });
      return { ok: false, message: `Twilio error: ${error.message}` };
    }
  }

  return { ok: false, message: `Unsupported OTP_PROVIDER: ${provider}` };
}

module.exports = {
  sendOtp
};
