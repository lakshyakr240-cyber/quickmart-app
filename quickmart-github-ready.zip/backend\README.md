# QuickMart Backend (Production Setup Scaffold)

This backend gives QuickMart a server layer, a persistent database, OTP provider hooks and Razorpay payment APIs.

## Stack
- Node.js + Express
- File DB (`backend/data/quickmart-db.json`) as persistent DB
- RPC bridge compatible with current frontend methods
- OTP send endpoint with provider integrations
- Razorpay order + verification endpoints

## 1) Install

```bash
cd backend
npm install
```

Windows CMD:

```bat
copy .env.example .env
npm run dev
```

Server runs on: `http://localhost:8787`

## 2) Frontend usage

Frontend files use `quickmart-api-bridge.js`.
By default it calls `http://localhost:8787/api/rpc`.

You can change API base from browser console:

```js
QuickMartApiBridge.setApiBase("https://api.yourdomain.com");
location.reload();
```

## 3) OTP setup (real SMS)

In `backend/.env` set:
- `OTP_PROVIDER=msg91` and MSG91 keys, OR
- `OTP_PROVIDER=twilio_verify` and Twilio keys.

In Admin panel OTP settings:
- Mode = `Webhook`
- URL = `http://localhost:8787/api/otp/send` (or your deployed URL)

## 4) Payment setup (Razorpay)

Set in `.env`:
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`

Endpoints:
- `POST /api/payments/razorpay/order`
- `POST /api/payments/razorpay/verify`

Frontend helper:
- `window.QuickMartPayments.createRazorpayOrder(payload)`
- `window.QuickMartPayments.verifyRazorpayPayment(payload)`

## 5) What is stored in DB

JSON file: `backend/data/quickmart-db.json`
- `kv_store` (global state + per-client sessions/cart)
- `otp_logs`
- `payment_logs`

## 6) Production checklist

- Put backend behind HTTPS (Nginx/Cloudflare)
- Restrict CORS to your domain
- Add rate limiting and request auth hardening
- Move from demo PIN handling to hashed server auth for full production
- Add monitoring and backups
