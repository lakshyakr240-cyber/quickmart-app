const path = require("path");
const express = require("express");
const cors = require("cors");
const morgan = require("morgan");
const dotenv = require("dotenv");
const { initDb, dbPath } = require("./db");
const { runQuickMartMethod } = require("./quickmartEngine");
const { sendOtp } = require("./services/otpService");
const { createRazorpayOrder, verifyRazorpayPayment } = require("./services/paymentService");

dotenv.config({ path: path.resolve(__dirname, "..", ".env") });

initDb();

const app = express();
const PORT = Number(process.env.PORT || 8787);
const PROJECT_ROOT = path.resolve(__dirname, "..", "..");

const ALLOWED_RPC_METHODS = new Set([
  "ORDER_STEPS",
  "formatINR",
  "getState",
  "getProducts",
  "getCategories",
  "getSettings",
  "getCart",
  "setCart",
  "addToCart",
  "updateCartItem",
  "clearCart",
  "getCartDetails",
  "calculateDeliverySummary",
  "getCustomerSession",
  "setCustomerSession",
  "clearCustomerSession",
  "normalizePhoneInput",
  "normalizePinInput",
  "normalizeDigitsInput",
  "createOtp",
  "requestOtp",
  "verifyOtp",
  "loginAdmin",
  "loginVendor",
  "loginDelivery",
  "getRoleSession",
  "clearRoleSession",
  "createOrder",
  "getOrders",
  "getDeliveryPartners",
  "getCustomerOrders",
  "getCustomerProfile",
  "updateCustomerProfile",
  "addCustomerAddress",
  "deleteCustomerAddress",
  "setDefaultCustomerAddress",
  "updateCustomerPreferences",
  "vendorDecision",
  "setProductStock",
  "assignDelivery",
  "markPickedUp",
  "markDelivered",
  "addCategory",
  "deleteCategory",
  "addProduct",
  "updateProduct",
  "deleteProduct",
  "updatePricingSettings",
  "updateOtpSettings",
  "addVendor",
  "addDeliveryPartner",
  "toggleUserActive",
  "toggleVendorActive",
  "toggleDeliveryPartnerActive",
  "getAdminDashboard",
  "getVendorPanelData",
  "getDeliveryPanelData",
  "resetAllData"
]);

app.use(cors({ origin: process.env.CORS_ORIGIN || "*" }));
app.use(express.json({ limit: "2mb" }));
app.use(morgan("dev"));

function clientIdFromRequest(req) {
  const headerId = String(req.headers["x-client-id"] || "").trim();
  const bodyId = req.body && typeof req.body.clientId === "string" ? req.body.clientId.trim() : "";
  return headerId || bodyId || "anonymous";
}

app.get("/api/health", (req, res) => {
  res.json({ ok: true, service: "quickmart-backend", dbPath, time: new Date().toISOString() });
});

app.post("/api/rpc", async (req, res) => {
  const method = String((req.body && req.body.method) || "").trim();
  const args = Array.isArray(req.body && req.body.args) ? req.body.args : [];
  const clientId = clientIdFromRequest(req);

  if (!method || !ALLOWED_RPC_METHODS.has(method)) {
    return res.status(400).json({ ok: false, message: `Unsupported RPC method: ${method || "(empty)"}` });
  }

  try {
    const result = await runQuickMartMethod(clientId, method, args);
    return res.json({ ok: true, result });
  } catch (error) {
    return res.status(500).json({ ok: false, message: error.message || "RPC execution failed." });
  }
});

app.post("/api/otp/send", async (req, res) => {
  const result = await sendOtp(req.body || {}, process.env);
  const code = result.ok ? 200 : 400;
  return res.status(code).json(result);
});

app.post("/api/payments/razorpay/order", async (req, res) => {
  const result = await createRazorpayOrder(req.body || {}, process.env);
  const code = result.ok ? 200 : 400;
  return res.status(code).json(result);
});

app.post("/api/payments/razorpay/verify", (req, res) => {
  const result = verifyRazorpayPayment(req.body || {}, process.env);
  const code = result.ok ? 200 : 400;
  return res.status(code).json(result);
});

// Serve frontend files from project root so app can run from one backend origin.
app.use(express.static(PROJECT_ROOT));

app.listen(PORT, () => {
  console.log(`QuickMart backend running on http://localhost:${PORT}`);
});
