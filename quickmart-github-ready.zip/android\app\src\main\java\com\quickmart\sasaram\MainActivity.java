package com.quickmart.sasaram;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
