$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$www = Join-Path $root "www"

if (Test-Path $www) {
  Remove-Item -Recurse -Force $www
}
New-Item -ItemType Directory -Force $www | Out-Null

$files = @(
  "index.html",
  "admin.html",
  "vendor.html",
  "delivery.html",
  "styles.css",
  "quickmart-data.js",
  "quickmart-config.js",
  "quickmart-api-bridge.js",
  "customer.js",
  "admin.js",
  "vendor.js",
  "delivery.js"
)

foreach ($file in $files) {
  Copy-Item -Path (Join-Path $root $file) -Destination (Join-Path $www $file) -Force
}

Write-Output "www folder prepared successfully."
