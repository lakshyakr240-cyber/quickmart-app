const fs = require("fs");
const path = require("path");

const dataDir = path.resolve(__dirname, "..", "data");
const dbPath = path.join(dataDir, "quickmart-db.json");

if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

function createEmptyState() {
  return {
    kv_store: {},
    otp_logs: [],
    payment_logs: []
  };
}

function safeReadState() {
  if (!fs.existsSync(dbPath)) {
    return createEmptyState();
  }

  try {
    const raw = fs.readFileSync(dbPath, "utf8");
    if (!raw || !raw.trim()) {
      return createEmptyState();
    }
    const parsed = JSON.parse(raw);
    return {
      kv_store: parsed && typeof parsed.kv_store === "object" && parsed.kv_store ? parsed.kv_store : {},
      otp_logs: Array.isArray(parsed && parsed.otp_logs) ? parsed.otp_logs : [],
      payment_logs: Array.isArray(parsed && parsed.payment_logs) ? parsed.payment_logs : []
    };
  } catch (error) {
    return createEmptyState();
  }
}

let state = safeReadState();

function persistState() {
  fs.writeFileSync(dbPath, JSON.stringify(state, null, 2), "utf8");
}

function initDb() {
  if (!state || typeof state !== "object") {
    state = createEmptyState();
  }
  if (!state.kv_store || typeof state.kv_store !== "object") {
    state.kv_store = {};
  }
  if (!Array.isArray(state.otp_logs)) {
    state.otp_logs = [];
  }
  if (!Array.isArray(state.payment_logs)) {
    state.payment_logs = [];
  }
  persistState();
}

function getKV(key) {
  const normalizedKey = String(key || "");
  if (!Object.prototype.hasOwnProperty.call(state.kv_store, normalizedKey)) {
    return null;
  }
  return String(state.kv_store[normalizedKey]);
}

function setKV(key, value) {
  const normalizedKey = String(key || "");
  state.kv_store[normalizedKey] = String(value || "");
  persistState();
}

function delKV(key) {
  const normalizedKey = String(key || "");
  delete state.kv_store[normalizedKey];
  persistState();
}

function logOtp(payload) {
  const now = new Date().toISOString();
  state.otp_logs.push({
    id: `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    mobile: payload.mobile || "",
    provider: payload.provider || "",
    status: payload.status || "",
    error: payload.error || "",
    payload: payload.request ? JSON.stringify(payload.request) : "",
    response: payload.response ? JSON.stringify(payload.response) : "",
    created_at: now
  });
  persistState();
}

function logPayment(payload) {
  const now = new Date().toISOString();
  state.payment_logs.push({
    id: `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    order_id: payload.orderId || "",
    provider_order_id: payload.providerOrderId || "",
    provider_payment_id: payload.providerPaymentId || "",
    status: payload.status || "",
    amount: Number(payload.amount || 0),
    currency: payload.currency || "INR",
    raw: payload.raw ? JSON.stringify(payload.raw) : "",
    created_at: now
  });
  persistState();
}

module.exports = {
  initDb,
  getKV,
  setKV,
  delKV,
  logOtp,
  logPayment,
  dbPath
};
