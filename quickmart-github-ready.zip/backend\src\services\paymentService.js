const crypto = require("crypto");
const { logPayment } = require("../db");

function basicAuth(key, secret) {
  return Buffer.from(`${key}:${secret}`).toString("base64");
}

async function createRazorpayOrder(payload, env) {
  const keyId = String(env.RAZORPAY_KEY_ID || "").trim();
  const keySecret = String(env.RAZORPAY_KEY_SECRET || "").trim();
  if (!keyId || !keySecret) {
    return { ok: false, message: "Razorpay credentials missing in backend .env." };
  }

  const amount = Number(payload.amount || 0);
  const receipt = String(payload.receipt || `rcpt_${Date.now()}`);
  const currency = String(payload.currency || "INR");

  if (!Number.isFinite(amount) || amount <= 0) {
    return { ok: false, message: "Valid amount is required." };
  }

  try {
    const response = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: {
        Authorization: `Basic ${basicAuth(keyId, keySecret)}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ amount, currency, receipt })
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      logPayment({
        orderId: receipt,
        providerOrderId: "",
        providerPaymentId: "",
        status: "create-failed",
        amount,
        currency,
        raw: data
      });
      return { ok: false, message: data.error && data.error.description ? data.error.description : `Razorpay failed (${response.status}).` };
    }

    logPayment({
      orderId: receipt,
      providerOrderId: data.id || "",
      providerPaymentId: "",
      status: "created",
      amount,
      currency,
      raw: data
    });

    return {
      ok: true,
      provider: "razorpay",
      keyId,
      order: data
    };
  } catch (error) {
    return { ok: false, message: `Razorpay error: ${error.message}` };
  }
}

function verifyRazorpayPayment(payload, env) {
  const keySecret = String(env.RAZORPAY_KEY_SECRET || "").trim();
  if (!keySecret) {
    return { ok: false, message: "Razorpay secret missing in backend .env." };
  }

  const orderId = String(payload.razorpay_order_id || "");
  const paymentId = String(payload.razorpay_payment_id || "");
  const signature = String(payload.razorpay_signature || "");

  if (!orderId || !paymentId || !signature) {
    return { ok: false, message: "Payment verification payload incomplete." };
  }

  const generated = crypto
    .createHmac("sha256", keySecret)
    .update(`${orderId}|${paymentId}`)
    .digest("hex");

  const verified = generated === signature;

  logPayment({
    orderId,
    providerOrderId: orderId,
    providerPaymentId: paymentId,
    status: verified ? "verified" : "verification-failed",
    amount: Number(payload.amount || 0),
    currency: String(payload.currency || "INR"),
    raw: payload
  });

  if (!verified) {
    return { ok: false, message: "Invalid Razorpay signature." };
  }

  return { ok: true, message: "Payment verified.", paymentId, orderId };
}

module.exports = {
  createRazorpayOrder,
  verifyRazorpayPayment
};
