const fs = require("fs");
const path = require("path");
const vm = require("vm");
const { getKV, setKV, delKV } = require("./db");

const ROOT = path.resolve(__dirname, "..", "..");
const QUICKMART_DATA_FILE = path.join(ROOT, "quickmart-data.js");
const QUICKMART_DATA_CODE = fs.readFileSync(QUICKMART_DATA_FILE, "utf8");

const GLOBAL_KEYS = new Set(["quickmart_state_v1"]);

function mapStorageKey(clientId, key) {
  const normalizedClient = String(clientId || "anonymous").trim() || "anonymous";
  if (GLOBAL_KEYS.has(key)) {
    return `global:${key}`;
  }
  return `client:${normalizedClient}:${key}`;
}

function createStorage(clientId) {
  return {
    getItem(key) {
      return getKV(mapStorageKey(clientId, String(key || "")));
    },
    setItem(key, value) {
      setKV(mapStorageKey(clientId, String(key || "")), String(value || ""));
    },
    removeItem(key) {
      delKV(mapStorageKey(clientId, String(key || "")));
    }
  };
}

async function runQuickMartMethod(clientId, method, args) {
  const storage = createStorage(clientId);
  const windowObject = {
    localStorage: storage,
    fetch: global.fetch,
    console
  };
  windowObject.window = windowObject;

  const context = vm.createContext({
    window: windowObject,
    console,
    fetch: global.fetch,
    setTimeout,
    clearTimeout,
    setInterval,
    clearInterval,
    Date,
    Math,
    JSON,
    Promise,
    encodeURIComponent,
    decodeURIComponent,
    String,
    Number,
    Boolean,
    Object,
    Array,
    RegExp,
    Error
  });

  vm.runInContext(QUICKMART_DATA_CODE, context, { filename: "quickmart-data.js" });

  const api = context.window && context.window.QuickMartData;
  if (!api || typeof api[method] !== "function") {
    throw new Error(`Unsupported method: ${method}`);
  }

  const result = api[method].apply(api, Array.isArray(args) ? args : []);
  if (result && typeof result.then === "function") {
    return await result;
  }
  return result;
}

module.exports = {
  runQuickMartMethod
};
